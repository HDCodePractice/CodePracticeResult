// cards: one player's cards, maybe have one to five
// return : pair card and more cards, form max to min, if haven't one pair,retrun []
public func isOnePair(cards:[Int])->[Int]{
    return []
}

// player1 & player2 : player's cards, from 2 to 14
// return: 0: tie, 1: player1 won, 2: player2 won
public func checkOnePair(player1:[Int],player2:[Int])-> Int{
    return 0
}
