
public func outPut(
    outputPrompt:String,
    outputElements:[String],
    errorPrompt:String,
    defaultInput: String
){
    
}
