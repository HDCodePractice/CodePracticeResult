
public func showString(_ string: String){
    // 如果是cmd
    //    print(string)
    // 如果是swift playgrounds
    show(string)
}
